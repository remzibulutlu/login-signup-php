<!DOCTYPE html>
<head>
<link rel="stylesheet" href="/styles.css">
</head>
<body>


<?php
    require_once 'header.php';
?>

<main>
    <?php
        if (isset($_SESSION['id'])) {
            echo '<p>You are logged in</p>';
        } else {
            echo '<p>You are logged out</p>';
        }
    ?>
</main>

<?php
    require_once 'footer.php';
?>

</body>
</html>